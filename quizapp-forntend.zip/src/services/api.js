// quiz-frontend/src/services/api.js
const API_BASE_URL = 'http://localhost:8080';

const getAuthHeaders = () => ({
  'Authorization': `Bearer ${localStorage.getItem('token')}`,
  'Content-Type': 'application/json'
});

const handleResponse = async (response) => {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error: ${response.status} - ${errorText}`);
  }
  return response.json();
};

export const apiService = {
  // Tournament APIs
  async getTournaments() {
    const response = await fetch(`${API_BASE_URL}/tournaments`, {
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

  async createTournament(data) {
    const response = await fetch(`${API_BASE_URL}/tournaments/create`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return handleResponse(response);
  },

  async updateTournament(id, data) {
    const response = await fetch(`${API_BASE_URL}/tournaments/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return handleResponse(response);
  },

 
  async deleteTournament(id) {
    const response = await fetch(`${API_BASE_URL}/tournaments/${id}?confirm=yes`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `Failed to delete tournament`);
    }
    
    return response.json();
  },

  async likeTournament(id) {
    const response = await fetch(`${API_BASE_URL}/tournaments/like/${id}`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

  async getScoreboard(id) {
    const response = await fetch(`${API_BASE_URL}/tournaments/${id}/scores`, {
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

  async getTournamentQuestions(tournamentId) {
    // Try admin endpoint first, fall back to player endpoint
    const user = JSON.parse(localStorage.getItem('user'));
    let endpoint;
    
    if (user && user.role === 'ADMIN') {
        endpoint = `${API_BASE_URL}/tournaments/${tournamentId}/questions`;
    } else {
        endpoint = `${API_BASE_URL}/player/tournament/${tournamentId}/questions`;
    }
    
    const response = await fetch(endpoint, {
        headers: getAuthHeaders()
    });
    
    if (!response.ok) {
        throw new Error(`Failed to fetch tournament questions: ${response.status}`);
    }
    
    return response.json();
},

  // Player APIs
  async startTournament(id) {
    const response = await fetch(`${API_BASE_URL}/player/start/${id}`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

  async getMyAttempts() {
    const response = await fetch(`${API_BASE_URL}/player/my-attempts`, {
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

  async getPlayerStats() {
  try {
    const response = await fetch(`${API_BASE_URL}/users/stats`, {
      headers: getAuthHeaders()
    });
    
    if (!response.ok) {
      console.error('Stats API response not ok:', response.status);
      throw new Error(`Stats API Error: ${response.status}`);
    }
    
    const stats = await response.json();
    console.log('Stats received from backend:', stats);
    return stats;
    
  } catch (error) {
    console.error('Error fetching player stats:', error);
    // Return default stats instead of throwing
    return {
      tournamentsPlayed: 0,
      averageScore: 0.0,
      bestScore: 0,
      totalPoints: 0
    };
  }
},

  async getTournamentQuestions(tournamentId) {
    const response = await fetch(`${API_BASE_URL}/player/tournament/${tournamentId}/questions`, {
      headers: getAuthHeaders()
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch tournament questions: ${response.status}`);
    }
    
    return response.json();
  },

  async submitAnswer(data) {
    const response = await fetch(`${API_BASE_URL}/player/submit-answer`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return handleResponse(response);
  },

  async getProfile() {
  const response = await fetch(`${API_BASE_URL}/users/profile`, {
    headers: getAuthHeaders()
  });
  return handleResponse(response);
},

// Update user profile
async updateProfile(profileData) {
  const response = await fetch(`${API_BASE_URL}/users/profile`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(profileData)
  });
  return handleResponse(response);
},

async uploadProfilePicture(file) {
  const formData = new FormData();
  formData.append('profilePicture', file);
  
  const response = await fetch(`${API_BASE_URL}/users/profile/picture`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`
      // Don't set Content-Type, let browser set it for FormData
    },
    body: formData
  });
  return handleResponse(response);
},

// Change password
async changePassword(passwordData) {
  const response = await fetch(`${API_BASE_URL}/users/change-password`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(passwordData)
  });
  return handleResponse(response);
},

  async finishTournament(attemptId) {
    const response = await fetch(`${API_BASE_URL}/player/finish/${attemptId}`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return handleResponse(response);
  },

async getAttemptAnswers(attemptId) {
  const response = await fetch(`${API_BASE_URL}/player/attempt/${attemptId}/answers`, {
    headers: getAuthHeaders()
  });
  return handleResponse(response);
},


  // Additional methods for better error handling
  async testConnection() {
    try {
      const response = await fetch(`${API_BASE_URL}/tournaments/debug-auth`, {
        headers: getAuthHeaders()
      });
      return response.ok;
    } catch (error) {
      console.error('Connection test failed:', error);
      return false;
    }
  }
};